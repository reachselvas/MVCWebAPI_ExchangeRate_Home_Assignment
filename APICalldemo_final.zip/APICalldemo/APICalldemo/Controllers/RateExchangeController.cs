﻿using APICalldemo.Models;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;

namespace APICalldemo.Controllers
{
    public class RateExchangeController : Controller
    {
        //
        // GET: /RateExchange/
        public ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Method to get exchange rate based on dates and currency.
        /// </summary>
        /// <param name="startDate">To pass the start date</param>
        /// <param name="endDate">To pass the end date</param>
        /// <param name="baseCurrency">To pass the base currency</param>
        /// <param name="targetCurrency">To pass the target currency</param>
        /// <returns>JSON</returns>
        public JsonResult ExchangeRate(string startDate, string endDate, string baseCurrency, string targetCurrency)
        {
            baseCurrency = baseCurrency.ToUpper();
            targetCurrency = targetCurrency.ToUpper();

            // Calling the WebAPI URL
            string apiUrl = "https://api.exchangeratesapi.io/history?start_at=" + startDate + "&end_at=" + endDate + "&base=" + baseCurrency + "&target=" + targetCurrency + "";
            WebClient client = new WebClient();
            client.Headers["Content-type"] = "application/json";
            client.Encoding = Encoding.UTF8;
            string json = client.DownloadString(apiUrl);

            JavaScriptSerializer json_serializer = new JavaScriptSerializer();
            var deserializedJson = json_serializer.Deserialize<Rateexchange>(json);

            var objParseJson = JObject.Parse(json);

            var rateExchangeVal = deserializedJson.rates.Select(x => x.Value);

            double minRate = 0;
            double maxRate = 0;
            double avgRate = 0;

            if (targetCurrency == "HUF")
            {
                minRate = rateExchangeVal.Select(x => x.HUF).Min();
                maxRate = rateExchangeVal.Select(x => x.HUF).Max();
                avgRate = rateExchangeVal.Select(x => x.HUF).Average();
            }
            else if (targetCurrency == "IDR")
            {
                minRate = rateExchangeVal.Select(x => x.IDR).Min();
                maxRate = rateExchangeVal.Select(x => x.IDR).Max();
                avgRate = rateExchangeVal.Select(x => x.IDR).Average();
            }
            else if (targetCurrency == "HKD")
            {
                minRate = rateExchangeVal.Select(x => x.HKD).Min();
                maxRate = rateExchangeVal.Select(x => x.HKD).Max();
                avgRate = rateExchangeVal.Select(x => x.HKD).Average();
            }
            else if (targetCurrency == "CZK")
            {
                minRate = rateExchangeVal.Select(x => x.CZK).Min();
                maxRate = rateExchangeVal.Select(x => x.CZK).Max();
                avgRate = rateExchangeVal.Select(x => x.CZK).Average();
            }
            else if (targetCurrency == "ILS")
            {

                minRate = rateExchangeVal.Select(x => x.ILS).Min();
                maxRate = rateExchangeVal.Select(x => x.ILS).Max();
                avgRate = rateExchangeVal.Select(x => x.ILS).Average();
            }
            else if (targetCurrency == "BGN")
            {

                minRate = rateExchangeVal.Select(x => x.BGN).Min();
                maxRate = rateExchangeVal.Select(x => x.BGN).Max();
                avgRate = rateExchangeVal.Select(x => x.BGN).Average();
            }
            else if (targetCurrency == "DKK")
            {

                minRate = rateExchangeVal.Select(x => x.DKK).Min();
                maxRate = rateExchangeVal.Select(x => x.DKK).Max();
                avgRate = rateExchangeVal.Select(x => x.DKK).Average();
            }
            else if (targetCurrency == "PHP")
            {

                minRate = rateExchangeVal.Select(x => x.PHP).Min();
                maxRate = rateExchangeVal.Select(x => x.PHP).Max();
                avgRate = rateExchangeVal.Select(x => x.PHP).Average();
            }
            else if (targetCurrency == "MYR")
            {

                minRate = rateExchangeVal.Select(x => x.MYR).Min();
                maxRate = rateExchangeVal.Select(x => x.MYR).Max();
                avgRate = rateExchangeVal.Select(x => x.MYR).Average();
            }
            else if (targetCurrency == "AUD")
            {

                minRate = rateExchangeVal.Select(x => x.AUD).Min();
                maxRate = rateExchangeVal.Select(x => x.AUD).Max();
                avgRate = rateExchangeVal.Select(x => x.AUD).Average();
            }
            else if (targetCurrency == "THB")
            {

                minRate = rateExchangeVal.Select(x => x.THB).Min();
                maxRate = rateExchangeVal.Select(x => x.THB).Max();
                avgRate = rateExchangeVal.Select(x => x.THB).Average();
            }
            else if (targetCurrency == "CNY")
            {

                minRate = rateExchangeVal.Select(x => x.CNY).Min();
                maxRate = rateExchangeVal.Select(x => x.CNY).Max();
                avgRate = rateExchangeVal.Select(x => x.CNY).Average();
            }
            else if (targetCurrency == "KRW")
            {

                minRate = rateExchangeVal.Select(x => x.KRW).Min();
                maxRate = rateExchangeVal.Select(x => x.KRW).Max();
                avgRate = rateExchangeVal.Select(x => x.KRW).Average();
            }
            else if (targetCurrency == "GBP")
            {

                minRate = rateExchangeVal.Select(x => x.GBP).Min();
                maxRate = rateExchangeVal.Select(x => x.GBP).Max();
                avgRate = rateExchangeVal.Select(x => x.GBP).Average();
            }
            else if (targetCurrency == "RON")
            {

                minRate = rateExchangeVal.Select(x => x.RON).Min();
                maxRate = rateExchangeVal.Select(x => x.RON).Max();
                avgRate = rateExchangeVal.Select(x => x.RON).Average();
            }
            else if (targetCurrency == "JPY")
            {

                minRate = rateExchangeVal.Select(x => x.PLN).Min();
                maxRate = rateExchangeVal.Select(x => x.PLN).Max();
                avgRate = rateExchangeVal.Select(x => x.PLN).Average();
            }
            else if (targetCurrency == "INR")
            {

                minRate = rateExchangeVal.Select(x => x.INR).Min();
                maxRate = rateExchangeVal.Select(x => x.INR).Max();
                avgRate = rateExchangeVal.Select(x => x.INR).Average();
            }
            else if (targetCurrency == "NOK")
            {

                minRate = rateExchangeVal.Select(x => x.NOK).Min();
                maxRate = rateExchangeVal.Select(x => x.NOK).Max();
                avgRate = rateExchangeVal.Select(x => x.NOK).Average();
            }
            else if (targetCurrency == "HRK")
            {

                minRate = rateExchangeVal.Select(x => x.HRK).Min();
                maxRate = rateExchangeVal.Select(x => x.HRK).Max();
                avgRate = rateExchangeVal.Select(x => x.HRK).Average();
            }
            else if (targetCurrency == "BRL")
            {

                minRate = rateExchangeVal.Select(x => x.BRL).Min();
                maxRate = rateExchangeVal.Select(x => x.BRL).Max();
                avgRate = rateExchangeVal.Select(x => x.BRL).Average();
            }
            else if (targetCurrency == "NZD")
            {

                minRate = rateExchangeVal.Select(x => x.NZD).Min();
                maxRate = rateExchangeVal.Select(x => x.NZD).Max();
                avgRate = rateExchangeVal.Select(x => x.NZD).Average();
            }
            else if (targetCurrency == "RUB")
            {

                minRate = rateExchangeVal.Select(x => x.RUB).Min();
                maxRate = rateExchangeVal.Select(x => x.RUB).Max();
                avgRate = rateExchangeVal.Select(x => x.RUB).Average();
            }
            else if (targetCurrency == "EUR")
            {

                minRate = rateExchangeVal.Select(x => x.EUR).Min();
                maxRate = rateExchangeVal.Select(x => x.EUR).Max();
                avgRate = rateExchangeVal.Select(x => x.EUR).Average();
            }
            else if (targetCurrency == "CAD")
            {

                minRate = rateExchangeVal.Select(x => x.CAD).Min();
                maxRate = rateExchangeVal.Select(x => x.CAD).Max();
                avgRate = rateExchangeVal.Select(x => x.CAD).Average();
            }
            else if (targetCurrency == "SGD")
            {

                minRate = rateExchangeVal.Select(x => x.SGD).Min();
                maxRate = rateExchangeVal.Select(x => x.SGD).Max();
                avgRate = rateExchangeVal.Select(x => x.SGD).Average();
            }
            else if (targetCurrency == "USD")
            {

                minRate = rateExchangeVal.Select(x => x.USD).Min();
                maxRate = rateExchangeVal.Select(x => x.USD).Max();
                avgRate = rateExchangeVal.Select(x => x.USD).Average();
            }
            else if (targetCurrency == "SEK")
            {

                minRate = rateExchangeVal.Select(x => x.SEK).Min();
                maxRate = rateExchangeVal.Select(x => x.SEK).Max();
                avgRate = rateExchangeVal.Select(x => x.SEK).Average();
            }
            else if (targetCurrency == "ZAR")
            {

                minRate = rateExchangeVal.Select(x => x.ZAR).Min();
                maxRate = rateExchangeVal.Select(x => x.ZAR).Max();
                avgRate = rateExchangeVal.Select(x => x.ZAR).Average();
            }

            var input = new
            {
                minRateValue = minRate.ToString(),
                maxRateValue = maxRate.ToString(),
                avgRateValue = avgRate.ToString()
            };

            return Json(input, JsonRequestBehavior.AllowGet);
        }
    }
}