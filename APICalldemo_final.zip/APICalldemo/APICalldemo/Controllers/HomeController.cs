﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net;
using System.Text;
using System.Web.Http;

namespace APICalldemo.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Title = "Home Page";
            DateTime Startdate = DateTime .Parse ("2018-01-15");
            DateTime Enddate = DateTime.Parse("2018-02-12");
            string apiUrl = "https://exchangeratesapi.io/";
            var input = new
            {
                Starttime = Startdate ,
                Endtime = Enddate ,
                BaseCurrency = "SEK",
                TargetCurrency ="NOK"
            };
            //string inputJson = (new JavaScriptSerializer()).Serialize(input);
            WebClient client = new WebClient();
            client.Headers["Content-type"] = "application/json";
            client.Encoding = Encoding.UTF8;
            //string json = client.UploadString(apiUrl + "", inputJson);
            return View();
        }
      
    }
}
